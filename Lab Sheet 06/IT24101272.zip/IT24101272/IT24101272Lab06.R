setwd("C:\\Users\\IT24101272\\Desktop\\IT24101272\\")
#part2
dbinom(40,44,0.92)

#part3
pbinom(35,44,0.92,lower.tail = TRUE)

#part4
1 - pbinom(37,44,0.92,lower.tail = TRUE)
pbinom(37,44,0.92,lower.tail = FALSE)

#part5
pbinom(42,44,0.92,lower.tail = TRUE) - pbinom(39,44,0.92,lower.tail = TRUE)

##Question02

#part1
#Number of babies born in a hospital on a given day

#part2
#poisson distribution
#Here, random variable X has poisson distribution with lamda=5

#part3
#It asls to find p(x=6). Following command gives the density.
#In other words, probability of getting an extact value canbe calculated using "dpois" command.
dpois(6,5)

#part4
#It asks to find p(x>6). This can find using "ppois" command as follows.
#If you keep "lower.tail" argument as "TRUE", that means P(X<=6)
#Since we need P(X>6), keep the "lower.tail" argument as "FALSE".
ppois(6,5,lower.tail = FALSE)







#Question01(i),(ii)

1-pbinom(46,50,0.85,lower.tail=TRUE)
pbinom(46,50,0.85,lower.tail = FALSE)

#Question02
dpois(15,12)






